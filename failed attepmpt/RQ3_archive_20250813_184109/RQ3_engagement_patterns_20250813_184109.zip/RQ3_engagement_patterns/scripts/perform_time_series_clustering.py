#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import subprocess
from datetime import datetime, timezone

import numpy as np
import pandas as pd


# --- Config ------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[2]

# Inputs (Step 5 & Step 6)
STEP5_BASE = PROJECT_ROOT / "RQ1_transition_rates_and_speeds/step5_weekly_datasets/dataset2_contributor_activity"
STEP5_CONTRIB_WEEKLY = STEP5_BASE / "contributor_activity_weekly.csv"
STEP5_PROJECT_RESULTS = STEP5_BASE / "project_results"
GIT_CLONES_DIR = PROJECT_ROOT / (
    "RQ1_transition_rates_and_speeds/data_mining/step1_repository_cloning/cloned_repositories"
)
STEP6_TRANSITIONS = PROJECT_ROOT / (
    "RQ1_transition_rates_and_speeds/step6_contributor_transitions/results/"
    "contributor_transitions.csv"
)

# Outputs
OUT_DIR = PROJECT_ROOT / "RQ3_engagement_patterns"
RESULTS_DIR = OUT_DIR / "results"
VIS_DIR = OUT_DIR / "visualizations"

# Time-series clustering params (env-overridable)
def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except Exception:
        return default


RESAMPLED_LENGTH = _env_int("RQ3_RESAMPLED_LENGTH", 20)
K_MIN = _env_int("RQ3_K_MIN", 2)
K_MAX = _env_int("RQ3_K_MAX", 8)
MAX_TS_PER_TYPE: Optional[int] = None
if os.environ.get("RQ3_MAX_TS_PER_TYPE"):
    try:
        MAX_TS_PER_TYPE = int(os.environ["RQ3_MAX_TS_PER_TYPE"])  # hard cap for build_series
    except Exception:
        MAX_TS_PER_TYPE = None

# Evaluate K using subsample to keep runtime reasonable
EVAL_SUBSAMPLE_PER_TYPE = _env_int("RQ3_EVAL_SUBSAMPLE_PER_TYPE", 1000)
RANDOM_SEED = _env_int("RQ3_RANDOM_SEED", 42)
USE_GIT_FALLBACK = os.environ.get("RQ3_USE_GIT_FALLBACK", "1") not in ("0", "false", "False")
GIT_MAX_PROJECTS = os.environ.get("RQ3_FALLBACK_GIT_MAX_PROJECTS")
GIT_MAX_PROJECTS = int(GIT_MAX_PROJECTS) if GIT_MAX_PROJECTS else None

# Plotting (lazy import)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# --- Utilities ----------------------------------------------------------------

def ensure_dirs() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    VIS_DIR.mkdir(parents=True, exist_ok=True)


def minmax_scale(series: np.ndarray) -> np.ndarray:
    smin = float(np.min(series))
    smax = float(np.max(series))
    if not math.isfinite(smin) or not math.isfinite(smax):
        return np.zeros_like(series, dtype=float)
    if smax - smin == 0:
        return np.zeros_like(series, dtype=float)
    return (series - smin) / (smax - smin)


def resample_series(values: np.ndarray, target_len: int) -> np.ndarray:
    if len(values) == target_len:
        return values.astype(float)
    if len(values) <= 1:
        return np.repeat(float(values[0]) if len(values) == 1 else 0.0, target_len)
    x_old = np.linspace(0.0, 1.0, num=len(values))
    x_new = np.linspace(0.0, 1.0, num=target_len)
    return np.interp(x_new, x_old, values).astype(float)


def chi_square_and_cramers_v(table: pd.DataFrame) -> Tuple[float, float, float]:
    from scipy.stats import chi2_contingency

    chi2, p, _, _ = chi2_contingency(table.values)
    n = table.values.sum()
    r, k = table.shape
    cramers_v = math.sqrt(chi2 / (n * (min(r - 1, k - 1)))) if n > 0 else 0.0
    return chi2, p, cramers_v


def scott_knott_ranking(groups: Dict[str, np.ndarray], alpha: float = 0.05) -> List[Tuple[List[str], float]]:
    """
    Minimal Scott–Knott style grouping by recursively partitioning groups to
    maximize between-groups sum of squares (BGSS), accepting splits with ANOVA p<alpha.
    Returns list of (group_names, mean) sorted by mean ascending.
    Note: This is a pragmatic implementation sufficient for ranking clusters by a metric.
    """
    import itertools
    from scipy.stats import f_oneway

    def bgss(groups_list: List[np.ndarray]) -> float:
        all_vals = np.concatenate(groups_list)
        grand_mean = float(np.mean(all_vals)) if len(all_vals) else 0.0
        return float(sum(len(g) * (np.mean(g) - grand_mean) ** 2 for g in groups_list))

    items = [(name, np.asarray(vals, dtype=float)) for name, vals in groups.items() if len(vals) > 0]
    if not items:
        return []

    def recurse(names_vals: List[Tuple[str, np.ndarray]]) -> List[List[Tuple[str, np.ndarray]]]:
        if len(names_vals) <= 1:
            return [names_vals]
        best_split = None
        base_bgss = bgss([v for _, v in names_vals])
        for i in range(1, 2 ** (len(names_vals) - 1)):
            left_idx = [j for j in range(len(names_vals)) if (i >> j) & 1]
            if not left_idx or len(left_idx) == len(names_vals):
                continue
            left = [names_vals[j] for j in left_idx]
            right = [names_vals[j] for j in range(len(names_vals)) if j not in left_idx]
            split_bgss = bgss([v for _, v in left] + [v for _, v in right])
            gain = split_bgss - base_bgss
            if best_split is None or gain > best_split[0]:
                best_split = (gain, left, right)
        if best_split is None:
            return [names_vals]
        _, left, right = best_split
        # ANOVA significance check
        try:
            f_p = f_oneway(*([v for _, v in left] + [v for _, v in right]))
            pval = float(f_p.pvalue)
        except Exception:
            pval = 1.0
        if pval < alpha:
            return recurse(left) + recurse(right)
        else:
            return [names_vals]

    grouped = recurse(items)
    # Convert to list of names and means, sorted by mean asc
    result: List[Tuple[List[str], float]] = []
    for grp in grouped:
        names = [n for n, _ in grp]
        vals = np.concatenate([v for _, v in grp])
        result.append((names, float(np.mean(vals)) if len(vals) else 0.0))
    result.sort(key=lambda x: x[1])
    return result


# --- Core Logic ----------------------------------------------------------------

def load_transitions(step6_path: Path) -> pd.DataFrame:
    if not step6_path.exists():
        print(f"[ERROR] Missing Step 6 transitions file: {step6_path}")
        sys.exit(2)
    usecols = [
        "project_name",
        "project_type",
        "contributor_email",
        "first_commit_date",
        "became_core",
        "first_core_date",
        "first_commit_week",
        "first_core_week",
        "weeks_to_core",
        "commits_to_core",
    ]
    df = pd.read_csv(step6_path, usecols=usecols)
    df = df[df["became_core"] == True]
    df = df[df["weeks_to_core"].fillna(0) > 0]  # exclude instant core
    if MAX_TS_PER_TYPE is not None:
        df = (
            df.groupby("project_type", group_keys=False)
            .apply(lambda g: g.sample(min(len(g), MAX_TS_PER_TYPE), random_state=RANDOM_SEED))
            .reset_index(drop=True)
        )
    return df.reset_index(drop=True)


def load_contrib_weekly_from_aggregate(step5_path: Path) -> Optional[pd.DataFrame]:
    if not step5_path.exists():
        return None
    usecols = ["project_name", "contributor_email", "week_number", "commits_this_week"]
    dtypes = {
        "project_name": "category",
        "contributor_email": "category",
        "week_number": np.int32,
        "commits_this_week": np.int32,
    }
    try:
        df = pd.read_csv(step5_path, usecols=usecols, dtype=dtypes)
    except Exception as e:
        print(f"[WARN] Failed reading aggregate weekly file: {e}")
        return None
    df.set_index(["project_name", "contributor_email"], inplace=True)
    return df


def load_contrib_weekly_from_project_files(transitions: pd.DataFrame) -> pd.DataFrame:
    """
    Fallback loader that reads per-project weekly files under project_results/ and
    constructs a combined DataFrame with the same columns used downstream.
    Only loads rows for (project, contributor) pairs present in transitions to
    keep memory usage reasonable.
    """
    if not STEP5_PROJECT_RESULTS.exists():
        print(f"[ERROR] Missing Step 5 project_results directory: {STEP5_PROJECT_RESULTS}")
        sys.exit(2)

    needed = transitions[["project_name", "contributor_email"]].drop_duplicates()
    # Map project_name to set of contributor emails we care about
    proj_to_emails: Dict[str, set] = {}
    for _, r in needed.iterrows():
        proj = r["project_name"]
        email = r["contributor_email"]
        proj_to_emails.setdefault(proj, set()).add(email)

    frames: List[pd.DataFrame] = []
    # project_results files follow pattern: <owner_repo>_activity.csv with project_name like "owner/repo"
    # We'll attempt to map by reading all files and filtering by project_name in file
    files = sorted([p for p in STEP5_PROJECT_RESULTS.glob("*_activity.csv") if p.is_file()])
    if not files:
        print(f"[ERROR] No per-project activity files found in {STEP5_PROJECT_RESULTS}")
        sys.exit(2)

    usecols = [
        "project_name",
        "contributor_email",
        "week_number",
        "commits_this_week",
    ]
    dtypes = {
        "project_name": "category",
        "contributor_email": "category",
        "week_number": np.int32,
        "commits_this_week": np.int32,
    }
    for fp in files:
        try:
            chunk = pd.read_csv(fp, usecols=usecols, dtype=dtypes)
        except Exception:
            # Some files might be empty or malformed; skip
            continue
        # Restrict to projects we actually need
        needed_projects = set(proj_to_emails.keys())
        chunk = chunk[chunk["project_name"].isin(needed_projects)]
        if chunk.empty:
            continue
        # For each project, filter to needed contributor emails
        # Merge trick: add a key to restrict rows
        chunk = chunk.merge(needed, on=["project_name", "contributor_email"], how="inner")
        if not chunk.empty:
            frames.append(chunk)

    if not frames:
        print("[ERROR] No matching rows found in per-project files for transitions.")
        sys.exit(2)

    df = pd.concat(frames, ignore_index=True)
    df.set_index(["project_name", "contributor_email"], inplace=True)
    return df


def build_series(
    transitions: pd.DataFrame, weekly: Optional[pd.DataFrame]
) -> Tuple[np.ndarray, List[Tuple[str, str, str, int, int, int]], List[np.ndarray]]:
    """
    Returns:
      X_ts: np.ndarray shape (n, RESAMPLED_LENGTH, 1)
      meta: list of tuples (project_name, project_type, contributor_email, first_week, core_week, weeks_to_core)
      raw_series: list of 1D arrays before resampling (for diagnostics)
    """
    meta: List[Tuple[str, str, str, int, int, int]] = []
    sequences: List[np.ndarray] = []
    raw_series: List[np.ndarray] = []

    # Pre-cache keys for availability check
    available_keys = set(weekly.index.unique()) if weekly is not None else set()

    # Cache: project -> {email_lower: sorted list of commit epoch seconds}
    project_commit_cache: Dict[str, Dict[str, List[int]]] = {}
    projects_processed = 0

    def owner_repo_dir(project_name: str) -> Optional[Path]:
        # project_name like "owner/repo" maps to "owner_repo"
        safe = project_name.replace("/", "_")
        d = GIT_CLONES_DIR / safe
        return d if d.exists() else None

    def load_project_commits(project_name: str) -> Optional[Dict[str, List[int]]]:
        nonlocal projects_processed
        if GIT_MAX_PROJECTS is not None and projects_processed >= GIT_MAX_PROJECTS:
            return None
        repo_dir = owner_repo_dir(project_name)
        if repo_dir is None:
            return None
        if project_name in project_commit_cache:
            return project_commit_cache[project_name]
        try:
            # author email and commit timestamp (unix)
            out = subprocess.check_output(
                ["git", "-C", str(repo_dir), "log", "--no-show-signature", "--pretty=%ct\t%ae"],
                stderr=subprocess.DEVNULL,
            ).decode("utf-8", errors="ignore")
        except Exception:
            return None
        mapping: Dict[str, List[int]] = {}
        for line in out.splitlines():
            if not line.strip():
                continue
            try:
                ts_str, email = line.split("\t", 1)
                ts = int(ts_str.strip())
                email_l = email.strip().lower()
                mapping.setdefault(email_l, []).append(ts)
            except Exception:
                continue
        # Sort each list
        for k in mapping:
            mapping[k].sort()
        project_commit_cache[project_name] = mapping
        projects_processed += 1
        return mapping

    for _, row in transitions.iterrows():
        proj = row["project_name"]
        ptype = str(row["project_type"]) if pd.notna(row["project_type"]) else "OSS"
        email = row["contributor_email"]
        first_w = int(row["first_commit_week"]) if pd.notna(row["first_commit_week"]) else 0
        core_w = int(row["first_core_week"]) if pd.notna(row["first_core_week"]) else (first_w + int(row["weeks_to_core"]))
        weeks_to_core = int(row["weeks_to_core"]) if pd.notna(row["weeks_to_core"]) else max(core_w - first_w, 1)

        key = (proj, email)
        series_commits: Optional[np.ndarray] = None

        if weekly is not None and key in available_keys:
            sub = weekly.loc[key]
            if not isinstance(sub, pd.DataFrame):
                sub = sub.to_frame().T
            sub = sub[["week_number", "commits_this_week"]].astype({"week_number": int, "commits_this_week": int})
            mask = (sub["week_number"] >= first_w) & (sub["week_number"] <= core_w)
            window = sub.loc[mask, ["week_number", "commits_this_week"]].sort_values("week_number")
            if not window.empty:
                all_weeks = np.arange(first_w, core_w + 1, dtype=int)
                tmp = pd.DataFrame({"week_number": all_weeks}).merge(
                    window, on="week_number", how="left"
                )
                series_commits = tmp["commits_this_week"].fillna(0).to_numpy(dtype=float)

        if series_commits is None and USE_GIT_FALLBACK:
            # Use git logs to reconstruct weekly commits from first_commit_date to first_core_date
            commits_map = load_project_commits(proj)
            if commits_map is not None:
                email_l = str(email).lower()
                ts_list = commits_map.get(email_l, [])
                if ts_list:
                    try:
                        first_dt = datetime.strptime(str(row["first_commit_date"]), "%Y-%m-%d").replace(tzinfo=timezone.utc)
                        core_dt = datetime.strptime(str(row.get("first_core_date", "")), "%Y-%m-%d").replace(tzinfo=timezone.utc)
                    except Exception:
                        # If dates missing or malformed, skip
                        first_dt = None
                        core_dt = None
                    if first_dt is not None and core_dt is not None:
                        start_ts = int(first_dt.timestamp())
                        end_ts = int(core_dt.timestamp())
                        # Bin into week offsets
                        length = max(2, weeks_to_core + 1)
                        counts = np.zeros(length, dtype=float)
                        for ts in ts_list:
                            if ts < start_ts or ts > end_ts:
                                continue
                            week_idx = int((ts - start_ts) // (7 * 24 * 3600))
                            if 0 <= week_idx < length:
                                counts[week_idx] += 1.0
                        if counts.sum() >= 0.0:
                            series_commits = counts

        if series_commits is None:
            continue
        # Drop leading zeros; keep at least length 2
        start_idx = 0
        while start_idx < len(series_commits) - 1 and series_commits[start_idx] == 0:
            start_idx += 1
        commits = series_commits[start_idx:]
        if len(commits) < 2:
            continue
        # Scale and resample
        scaled = minmax_scale(commits)
        sampled = resample_series(scaled, RESAMPLED_LENGTH)
        sequences.append(sampled.reshape(-1, 1))
        raw_series.append(commits.astype(float))
        meta.append((proj, ptype, email, first_w, core_w, weeks_to_core))

    if not sequences:
        print("[ERROR] No sequences constructed. Check inputs and filters.")
        sys.exit(3)

    X = np.stack(sequences, axis=0)
    return X, meta, raw_series


def try_import_tslearn():
    try:
        from tslearn.clustering import TimeSeriesKMeans, silhouette_score
        return TimeSeriesKMeans, silhouette_score
    except Exception as e:
        print("[ERROR] tslearn not available. Please install tslearn.")
        raise


def evaluate_k_range(X: np.ndarray, k_min: int, k_max: int, metric: str = "softdtw") -> pd.DataFrame:
    TimeSeriesKMeans, silhouette_score = try_import_tslearn()
    rows = []
    rng = np.random.RandomState(RANDOM_SEED)
    # Optional subsample to speed up silhouette evaluation
    if EVAL_SUBSAMPLE_PER_TYPE and X.shape[0] > EVAL_SUBSAMPLE_PER_TYPE:
        idx = rng.choice(X.shape[0], size=EVAL_SUBSAMPLE_PER_TYPE, replace=False)
        X_eval = X[idx]
    else:
        X_eval = X
    # Silhouette requires 2 <= n_labels <= n_samples - 1
    max_k_for_sil = max(2, min(k_max, X_eval.shape[0] - 1))
    min_k_for_sil = max(2, k_min)
    if X_eval.shape[0] <= 2:
        return pd.DataFrame([])
    for k in range(min_k_for_sil, max_k_for_sil + 1):
        try:
            model = TimeSeriesKMeans(
                n_clusters=k,
                metric=metric,
                max_iter=50,
                random_state=RANDOM_SEED,
                n_init=2,
                verbose=False,
            )
            labels = model.fit_predict(X_eval)
            sil = silhouette_score(X_eval, labels, metric=metric)
            inertia = float(model.inertia_)
            rows.append({"k": k, "silhouette": float(sil), "inertia": inertia})
            print(f"[K={k}] silhouette={sil:.4f} inertia={inertia:.2f}")
        except Exception as e:
            print(f"[WARN] K={k} failed: {e}")
    return pd.DataFrame(rows)


def fit_final_model(X: np.ndarray, k: int, metric: str = "softdtw"):
    TimeSeriesKMeans, _ = try_import_tslearn()
    model = TimeSeriesKMeans(
        n_clusters=k,
        metric=metric,
        max_iter=100,
        random_state=RANDOM_SEED,
        n_init=3,
        verbose=False,
    )
    labels = model.fit_predict(X)
    centers = model.cluster_centers_  # shape (k, L, 1)
    return model, labels, centers


def plot_cluster_centers(centers: np.ndarray, out_path: Path) -> None:
    k = centers.shape[0]
    plt.figure(figsize=(10, 6))
    for i in range(k):
        plt.plot(centers[i, :, 0], label=f"Cluster {i}")
    plt.title("Cluster Centroids (Soft-DTW)")
    plt.xlabel("Resampled Week Index")
    plt.ylabel("Scaled Commits")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()


def plot_distribution_by_type(dist: pd.DataFrame, out_path: Path) -> None:
    # dist: columns [cluster, OSS, OSS4SG]
    clusters = dist["cluster"].astype(str).tolist()
    oss_vals = dist["OSS"].to_numpy()
    sg_vals = dist["OSS4SG"].to_numpy()
    x = np.arange(len(clusters))
    width = 0.35
    plt.figure(figsize=(10, 6))
    plt.bar(x - width / 2, oss_vals, width=width, label="OSS")
    plt.bar(x + width / 2, sg_vals, width=width, label="OSS4SG")
    plt.xticks(x, clusters)
    plt.ylabel("Count")
    plt.title("Cluster Membership by Project Type")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()


def main() -> None:
    ensure_dirs()
    print("[INFO] Loading transitions (Step 6)...")
    transitions = load_transitions(STEP6_TRANSITIONS)
    print(f"[INFO] Transitions loaded: {len(transitions)} (became_core & non-instant)")

    print("[INFO] Loading contributor weekly activity (Step 5)...")
    weekly = load_contrib_weekly_from_aggregate(STEP5_CONTRIB_WEEKLY)
    if weekly is None:
        print("[INFO] Aggregate weekly file not available; reading per-project files...")
        weekly = load_contrib_weekly_from_project_files(transitions)
    print(f"[INFO] Weekly dataset index keys: {len(weekly.index.unique())}")

    print("[INFO] Building per-contributor pre-core time series...")
    X, meta, raw_series = build_series(transitions, weekly)
    print(f"[INFO] Built sequences: {X.shape[0]} of length {X.shape[1]}")

    print(f"[INFO] Evaluating K from {K_MIN} to {K_MAX} (Soft-DTW)...")
    eval_df = evaluate_k_range(X, K_MIN, K_MAX, metric="softdtw")
    eval_path = RESULTS_DIR / "silhouette_scores.csv"
    # Persist even if empty, for transparency
    try:
        eval_df.to_csv(eval_path, index=False)
    except Exception:
        pass
    if eval_df.empty:
        # Fallback: choose a feasible K bounded by sample size
        n_samples = X.shape[0]
        if n_samples < 2:
            print("[ERROR] Not enough sequences to cluster (need >=2). Exiting.")
            sys.exit(4)
        best_k = 2 if n_samples >= 2 else 1
        print(f"[INFO] Silhouette not applicable (n={n_samples}); falling back to K={best_k}.")
    else:
        best_row = eval_df.sort_values(["silhouette", "k"], ascending=[False, True]).iloc[0]
        best_k = int(best_row["k"])
        print(f"[INFO] Best K by silhouette: K={best_k} (silhouette={best_row['silhouette']:.4f})")

    print("[INFO] Fitting final model...")
    # Ensure K does not exceed number of samples
    best_k = min(best_k, max(2, X.shape[0]))
    model, labels, centers = fit_final_model(X, best_k, metric="softdtw")
    centers_path = RESULTS_DIR / "cluster_centers.npy"
    np.save(centers_path, centers)
    plot_cluster_centers(centers, VIS_DIR / "cluster_centroids.png")

    print("[INFO] Preparing outputs...")
    # Assemble assignment dataframe
    meta_cols = ["project_name", "project_type", "contributor_email", "first_week", "core_week", "weeks_to_core"]
    meta_df = pd.DataFrame(meta, columns=meta_cols)
    meta_df["cluster"] = labels
    # Attach commits_to_core
    meta_df = meta_df.merge(
        transitions[["project_name", "contributor_email", "commits_to_core"]],
        on=["project_name", "contributor_email"],
        how="left",
    )

    out_assign = RESULTS_DIR / "cluster_assignments.csv"
    meta_df.to_csv(out_assign, index=False)

    # Distribution by type
    dist = (
        meta_df.pivot_table(index="cluster", columns="project_type", values="contributor_email", aggfunc="count", fill_value=0)
        .reset_index()
    )
    # Ensure OSS/OSS4SG columns exist
    for col in ["OSS", "OSS4SG"]:
        if col not in dist.columns:
            dist[col] = 0
    dist = dist[["cluster", "OSS", "OSS4SG"]]
    dist.to_csv(RESULTS_DIR / "distribution_by_type.csv", index=False)

    plot_distribution_by_type(dist, VIS_DIR / "cluster_distribution_by_type.png")

    # Chi-square + Cramer's V
    try:
        chi2, p, v = chi_square_and_cramers_v(dist.set_index("cluster")[ ["OSS", "OSS4SG"] ])
        with open(RESULTS_DIR / "chi_square_distribution.txt", "w") as f:
            f.write(f"Chi-square={chi2:.4f}, p-value={p:.6g}, Cramer's V={v:.4f}\n")
    except Exception as e:
        with open(RESULTS_DIR / "chi_square_distribution.txt", "w") as f:
            f.write(f"Chi-square not computed: {e}\n")

    # Scott–Knott style ranking by weeks_to_core (which patterns reach core faster)
    groups_weeks: Dict[str, np.ndarray] = {}
    for c in sorted(meta_df["cluster"].unique()):
        vals = meta_df.loc[meta_df["cluster"] == c, "weeks_to_core"].dropna().to_numpy(dtype=float)
        if len(vals) > 0:
            groups_weeks[str(c)] = vals
    sk_weeks = scott_knott_ranking(groups_weeks, alpha=0.05)
    with open(RESULTS_DIR / "scott_knott_weeks_to_core.txt", "w") as f:
        for rank, (names, mean_val) in enumerate(sk_weeks, start=1):
            f.write(f"Rank {rank}: clusters={','.join(names)} mean_weeks_to_core={mean_val:.2f}\n")

    # Scott–Knott style ranking by commits_to_core
    groups_commits: Dict[str, np.ndarray] = {}
    for c in sorted(meta_df["cluster"].unique()):
        vals = meta_df.loc[meta_df["cluster"] == c, "commits_to_core"].dropna().to_numpy(dtype=float)
        if len(vals) > 0:
            groups_commits[str(c)] = vals
    sk_commits = scott_knott_ranking(groups_commits, alpha=0.05)
    with open(RESULTS_DIR / "scott_knott_commits_to_core.txt", "w") as f:
        for rank, (names, mean_val) in enumerate(sk_commits, start=1):
            f.write(f"Rank {rank}: clusters={','.join(names)} mean_commits_to_core={mean_val:.2f}\n")

    # Save a small JSON summary
    summary = {
        "best_k": best_k,
        "num_sequences": int(X.shape[0]),
        "sequence_length": int(X.shape[1]),
        "silhouette_scores": (
            eval_df.sort_values("k").to_dict(orient="records") if not eval_df.empty else []
        ),
        "chi_square": {
            "chi2": float(chi2) if 'chi2' in locals() else None,
            "p": float(p) if 'p' in locals() else None,
            "cramers_v": float(v) if 'v' in locals() else None,
        },
        "scott_knott_weeks": [{"clusters": names, "mean": mean} for names, mean in sk_weeks],
        "scott_knott_commits": [{"clusters": names, "mean": mean} for names, mean in sk_commits],
    }
    with open(RESULTS_DIR / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("[DONE] RQ3 time-series clustering complete.")


if __name__ == "__main__":
    main()


