## RQ3 — Engagement Patterns: Time-Series Clustering (Soft-DTW)

This module clusters pre-core engagement time series for contributors who became core (excluding instant cores: week 0), using Soft-DTW k-means. Each series spans from the contributor's first commit week to their first core week, based on Step 5/6 outputs produced in RQ1.

Inputs (read-only; do not modify outside RQ3):
- `RQ1_transition_rates_and_speeds/step6_contributor_transitions/results/contributor_transitions.csv`
- `RQ1_transition_rates_and_speeds/step5_weekly_datasets/dataset2_contributor_activity/contributor_activity_weekly.csv` (if available)
- Or per-project weekly activity files under `.../project_results/*.csv` (fallback)

Outputs:
- `RQ3_engagement_patterns/results/`
  - `silhouette_scores.csv`: K sweep metrics
  - `cluster_centers.npy`: centroid sequences
  - `cluster_assignments.csv`: per series metadata and cluster label
  - `distribution_by_type.csv`: OSS vs OSS4SG counts per cluster
  - `chi_square_distribution.txt`: chi-square & Cramer's V
  - `scott_knott_weeks_to_core.txt`, `scott_knott_commits_to_core.txt`: rankings by outcomes
- `RQ3_engagement_patterns/visualizations/`
  - `cluster_centroids.png`: centroid plots
  - `cluster_distribution_by_type.png`: bar chart of membership

Run (assumes `.venv` exists):
```
"/Users/mohamadashraf/Desktop/Projects/Newcomers OSS Vs. OSS4SG FSE 2026/.venv/bin/python3" RQ3_engagement_patterns/scripts/perform_time_series_clustering.py
```

Environment variables (optional):
- `RQ3_RESAMPLED_LENGTH` (default 20)
- `RQ3_K_MIN` (default 2), `RQ3_K_MAX` (default 8)
- `RQ3_MAX_TS_PER_TYPE`: cap per project_type for quick runs
- `RQ3_EVAL_SUBSAMPLE_PER_TYPE` (default 1000): silhouette subsample size
- `RQ3_RANDOM_SEED` (default 42)

Dependencies:
- pandas, numpy, scipy, matplotlib, tslearn
```
"/Users/mohamadashraf/Desktop/Projects/Newcomers OSS Vs. OSS4SG FSE 2026/.venv/bin/python3" -m pip install pandas numpy scipy matplotlib tslearn
```

Tester:
- `tester/test_rq3_pipeline.py` verifies inputs are accessible and basic outputs are produced.


