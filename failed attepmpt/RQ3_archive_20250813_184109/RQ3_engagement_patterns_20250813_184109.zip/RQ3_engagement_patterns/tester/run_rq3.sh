#!/bin/zsh
set -euo pipefail

ROOT="/Users/mohamadashraf/Desktop/Projects/Newcomers OSS Vs. OSS4SG FSE 2026"
VENV_PY="$ROOT/.venv/bin/python3"

echo "[RQ3] Installing deps (if needed)..."
$VENV_PY -m pip install -q pandas numpy scipy matplotlib tslearn

echo "[RQ3] Running clustering..."
$VENV_PY "$ROOT/RQ3_engagement_patterns/scripts/perform_time_series_clustering.py"

echo "[RQ3] Done. Outputs in RQ3_engagement_patterns/results and visualizations."


