import os
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def test_inputs_exist():
    step6 = PROJECT_ROOT / (
        "RQ1_transition_rates_and_speeds/step6_contributor_transitions/results/"
        "contributor_transitions.csv"
    )
    step5_dir = PROJECT_ROOT / (
        "RQ1_transition_rates_and_speeds/step5_weekly_datasets/dataset2_contributor_activity"
    )
    assert step6.exists(), f"Missing transitions: {step6}"
    assert step5_dir.exists(), f"Missing step5 dir: {step5_dir}"


def test_expected_outputs_dirs():
    out = PROJECT_ROOT / "RQ3_engagement_patterns"
    results = out / "results"
    vis = out / "visualizations"
    assert results.exists(), f"Missing results dir: {results}"
    assert vis.exists(), f"Missing visualizations dir: {vis}"


