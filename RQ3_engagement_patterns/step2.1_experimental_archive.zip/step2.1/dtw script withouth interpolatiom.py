import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
import gc
import psutil
import os
from datetime import datetime
import json
import pickle
warnings.filterwarnings('ignore')

from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import silhouette_score

# For DTW
try:
    from tslearn.clustering import TimeSeriesKMeans
    from tslearn.preprocessing import TimeSeriesScalerMeanVariance
    from tslearn.utils import to_time_series_dataset
    TSLEARN_AVAILABLE = True
except ImportError:
    TSLEARN_AVAILABLE = False
    print("❌ tslearn not installed! Please install: pip install tslearn")
    exit(1)


class MemoryOptimizedDTWClustering:
    """
    Memory-optimized DTW clustering for large datasets with limited RAM.
    """
    
    def __init__(self, data_path, output_dir="dtw_clustering_optimized", verbose=True):
        """Initialize DTW clustering with memory monitoring."""
        # Resolve paths
        script_dir = Path(__file__).resolve().parent
        
        data_path = Path(data_path)
        if not data_path.is_absolute():
            data_path = (script_dir / data_path).resolve()
        self.data_path = data_path

        output_dir = Path(output_dir)
        if not output_dir.is_absolute():
            output_dir = (script_dir / output_dir).resolve()
        self.output_dir = output_dir
        self.output_dir.mkdir(exist_ok=True, parents=True)

        self.verbose = verbose

        # Fail early if file doesn't exist
        if not self.data_path.exists():
            raise FileNotFoundError(f"Input data file not found: {self.data_path}")
            
        # Memory monitoring
        self.process = psutil.Process(os.getpid())
        
    def log(self, message, level="INFO"):
        """Log with timestamp and memory usage."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        memory_mb = self.process.memory_info().rss / 1024 / 1024
        
        if self.verbose:
            prefix = {
                "START": "🚀",
                "SUCCESS": "✅",
                "ERROR": "❌",
                "WARNING": "⚠️",
                "INFO": "ℹ️",
                "PROGRESS": "⏳",
                "SAVE": "💾",
                "MEMORY": "🧠"
            }.get(level, "")
            print(f"[{timestamp}] {prefix} {message} (RAM: {memory_mb:.0f}MB)")
    
    def force_cleanup(self):
        """Force garbage collection and memory cleanup."""
        gc.collect()
        
    def load_and_filter_optimized(self, min_active_weeks=6):
        """
        Memory-optimized data loading and filtering.
        """
        self.log("="*60, "INFO")
        self.log("LOADING AND FILTERING DATA (MEMORY OPTIMIZED)", "START")
        self.log("="*60, "INFO")
        self.log(f"Minimum activity requirement: {min_active_weeks} weeks", "INFO")
        
        # Load dataset in chunks to save memory
        self.log("Loading data in memory-efficient mode...", "PROGRESS")
        
        # Read header first to get column info
        sample_df = pd.read_csv(self.data_path, nrows=5)
        time_cols = [col for col in sample_df.columns if col.startswith('t_')]
        time_cols.sort(key=lambda x: int(x.split('_')[1]))
        
        meta_cols = ['contributor_id', 'project', 'project_type']
        meta_cols = [col for col in meta_cols if col in sample_df.columns]
        
        # Process data in smaller chunks
        chunk_size = 1000
        variable_length_series = []
        valid_metadata = []
        length_distribution = []
        total_processed = 0
        
        self.log(f"Processing data in chunks of {chunk_size}...", "PROGRESS")
        
        for chunk in pd.read_csv(self.data_path, chunksize=chunk_size):
            for idx, row in chunk.iterrows():
                if total_processed % 500 == 0:
                    self.log(f"Processed {total_processed} contributors...", "PROGRESS")
                
                # Get time series
                series = row[time_cols].values.astype(np.float32)  # Use float32 to save memory
                series_numeric = pd.to_numeric(series, errors='coerce')
                
                # Remove NaN values
                valid_values = series_numeric[~np.isnan(series_numeric)]
                
                if len(valid_values) == 0:
                    total_processed += 1
                    continue
                
                # Find actual activity period
                non_zero_indices = np.where(valid_values != 0)[0]
                
                # Check minimum activity requirement
                if len(non_zero_indices) < min_active_weeks:
                    total_processed += 1
                    continue
                
                # Extract activity period (convert to float32 to save memory)
                first_activity = non_zero_indices[0]
                last_activity = non_zero_indices[-1]
                activity_period = valid_values[first_activity:last_activity+1].astype(np.float32)
                
                # Store results
                variable_length_series.append(activity_period)
                valid_metadata.append(row[meta_cols].to_dict())
                length_distribution.append(len(activity_period))
                
                total_processed += 1
            
            # Force cleanup after each chunk
            self.force_cleanup()
        
        # Convert metadata to DataFrame
        self.metadata = pd.DataFrame(valid_metadata)
        self.series_list = variable_length_series
        self.lengths = np.array(length_distribution, dtype=np.int32)  # Use int32 to save memory
        
        # Force cleanup
        del valid_metadata, length_distribution
        self.force_cleanup()
        
        # Report statistics
        self.log(f"\nFiltering complete:", "SUCCESS")
        self.log(f"  Total contributors: {total_processed}", "INFO")
        self.log(f"  Valid contributors: {len(self.series_list)}", "INFO")
        self.log(f"  Filtered out: {total_processed - len(self.series_list)}", "INFO")
        self.log(f"\nSeries length distribution:", "INFO")
        self.log(f"  Min length: {self.lengths.min()} weeks", "INFO")
        self.log(f"  Max length: {self.lengths.max()} weeks", "INFO")
        self.log(f"  Median length: {np.median(self.lengths):.0f} weeks", "INFO")
        self.log(f"  Mean length: {self.lengths.mean():.1f} weeks", "INFO")
        
        # Create length distribution plot
        plt.figure(figsize=(10, 6))
        plt.hist(self.lengths, bins=50, edgecolor='black', alpha=0.7)
        plt.axvline(np.median(self.lengths), color='red', linestyle='--', 
                   label=f'Median: {np.median(self.lengths):.0f}')
        plt.xlabel('Series Length (weeks)')
        plt.ylabel('Number of Contributors')
        plt.title('Distribution of Time Series Lengths (After Filtering)')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.savefig(self.output_dir / 'series_length_distribution.png', dpi=150, bbox_inches='tight')
        plt.close()
        self.log(f"Length distribution plot saved", "SAVE")
        
        self.log("", "MEMORY")  # Show current memory usage
        
        return self.series_list, self.metadata
    
    def prepare_for_dtw_optimized(self, series_list, scaling='minmax'):
        """
        Memory-optimized DTW preparation.
        """
        self.log("Preparing data for DTW (memory optimized)...", "PROGRESS")
        
        # Scale each series individually and convert to float32
        scaled_series = []
        for i, series in enumerate(series_list):
            if i % 1000 == 0:
                self.log(f"Scaling series {i}/{len(series_list)}...", "PROGRESS")
            
            if scaling == 'minmax':
                # Scale to 0-1 using float32
                if series.max() > series.min():
                    scaled = ((series - series.min()) / (series.max() - series.min())).astype(np.float32)
                else:
                    scaled = series.astype(np.float32)
            elif scaling == 'standard':
                # Standardize using float32
                if series.std() > 0:
                    scaled = ((series - series.mean()) / series.std()).astype(np.float32)
                else:
                    scaled = series.astype(np.float32)
            else:
                scaled = series.astype(np.float32)
            
            scaled_series.append(scaled)
        
        # Convert to tslearn format with memory cleanup
        self.log("Converting to tslearn format...", "PROGRESS")
        tslearn_dataset = []
        for i, s in enumerate(scaled_series):
            if i % 1000 == 0 and i > 0:
                self.force_cleanup()  # Cleanup every 1000 series
            tslearn_dataset.append(s.reshape(-1, 1))
        
        # Clear original data
        del scaled_series
        self.force_cleanup()
        
        self.log(f"Prepared {len(tslearn_dataset)} series for DTW", "SUCCESS")
        self.log("", "MEMORY")
        
        return tslearn_dataset
    
    def cluster_with_dtw_optimized(self, tslearn_dataset, k):
        """
        Memory-optimized DTW clustering.
        """
        self.log(f"\n{'='*40}", "INFO")
        self.log(f"DTW CLUSTERING WITH k={k} (OPTIMIZED)", "START")
        self.log(f"{'='*40}", "INFO")
        
        start_time = datetime.now()
        
        # Use more aggressive memory-saving parameters
        self.log(f"Running DTW k-means with optimized parameters...", "PROGRESS")
        
        dtw_km = TimeSeriesKMeans(
            n_clusters=k,
            metric="dtw",
            max_iter=5,     # Reduced from 10
            n_init=1,       # Reduced from 3 to save memory
            random_state=42,
            verbose=1 if self.verbose else 0,
            n_jobs=1        # Single threaded to control memory
        )
        
        # Convert to tslearn format with memory monitoring
        self.log("Converting to tslearn dataset format...", "PROGRESS")
        X = to_time_series_dataset(tslearn_dataset)
        self.log("", "MEMORY")
        
        # Fit and predict
        self.log("Fitting DTW model...", "PROGRESS")
        labels = dtw_km.fit_predict(X)
        
        # Clear X to free memory
        del X
        self.force_cleanup()
        
        # Calculate silhouette score on full dataset
        self.log("Calculating silhouette score on full dataset...", "PROGRESS")
        
        # Convert to fixed-size array for silhouette - interpolate NaN values
        max_len = max(len(s) for s in tslearn_dataset)
        padded_data = np.zeros((len(tslearn_dataset), max_len), dtype=np.float32)
        
        for i, s in enumerate(tslearn_dataset):
            series_flat = s.reshape(-1)
            # Fill the actual data
            padded_data[i, :len(series_flat)] = series_flat
            # Interpolate remaining positions with last value (no NaN)
            if len(series_flat) < max_len:
                padded_data[i, len(series_flat):] = series_flat[-1]
        
        # Calculate silhouette on full dataset
        try:
            sil_score = silhouette_score(padded_data, labels, metric='euclidean')
            self.log(f"Silhouette score (full dataset): {sil_score:.4f}", "INFO")
        except Exception as e:
            self.log(f"Silhouette calculation failed: {e}", "WARNING")
            sil_score = -1.0  # Fallback value
        
        # Cleanup
        del padded_data
        self.force_cleanup()
        
        # Get cluster centers
        cluster_centers = dtw_km.cluster_centers_
        
        # Calculate cluster sizes
        unique_labels, counts = np.unique(labels, return_counts=True)
        for i, count in enumerate(counts):
            pct = 100 * count / len(labels)
            self.log(f"Cluster {i}: {count} contributors ({pct:.1f}%)", "INFO")
        
        elapsed_time = (datetime.now() - start_time).total_seconds()
        self.log(f"DTW clustering completed in {elapsed_time:.1f} seconds", "SUCCESS")
        self.log("", "MEMORY")
        
        return {
            'k': k,
            'labels': labels,
            'cluster_centers': cluster_centers,
            'silhouette': sil_score,
            'cluster_sizes': counts,
            'elapsed_time': elapsed_time
        }
    
    def visualize_dtw_results_optimized(self, tslearn_dataset, result, metadata):
        """
        Memory-optimized visualization.
        """
        k = result['k']
        labels = result['labels']
        cluster_centers = result['cluster_centers']
        
        self.log(f"Creating visualization for k={k}...", "PROGRESS")
        
        fig = plt.figure(figsize=(16, 10))  # Slightly smaller figure
        colors = plt.cm.Set1(np.linspace(0, 1, k))
        
        # 1. Cluster Centers
        ax1 = plt.subplot(2, 3, 1)
        for i, center in enumerate(cluster_centers):
            center_flat = center.reshape(-1)
            ax1.plot(center_flat, linewidth=3, label=f'Cluster {i}', 
                    color=colors[i], alpha=0.9)
        ax1.set_title(f'DTW Cluster Centers (k={k})', fontsize=12, fontweight='bold')
        ax1.set_xlabel('Time (weeks)', fontsize=10)
        ax1.set_ylabel('Normalized Activity', fontsize=10)
        ax1.legend(fontsize=9)
        ax1.grid(True, alpha=0.3)
        
        # 2. Sample series (reduced sample size)
        ax2 = plt.subplot(2, 3, 2)
        n_samples_per_cluster = min(10, len(tslearn_dataset) // k)  # Reduced samples
        
        for cluster_id in range(k):
            cluster_mask = labels == cluster_id
            cluster_indices = np.where(cluster_mask)[0]
            
            if len(cluster_indices) > 0:
                sample_size = min(n_samples_per_cluster, len(cluster_indices))
                sample_idx = np.random.choice(cluster_indices, sample_size, replace=False)
                
                for idx in sample_idx:
                    series = tslearn_dataset[idx].reshape(-1)
                    x = np.arange(len(series))
                    ax2.plot(x, series, alpha=0.2, color=colors[cluster_id])
                
                # Plot center
                center = cluster_centers[cluster_id].reshape(-1)
                x_center = np.arange(len(center))
                ax2.plot(x_center, center, linewidth=3, color=colors[cluster_id],
                        alpha=0.9, label=f'Center {cluster_id}')
        
        ax2.set_title('Sample Series with Centers', fontsize=12, fontweight='bold')
        ax2.set_xlabel('Time (weeks)', fontsize=10)
        ax2.set_ylabel('Normalized Activity', fontsize=10)
        ax2.legend(fontsize=8)
        ax2.grid(True, alpha=0.3)
        
        # 3. Cluster sizes
        ax3 = plt.subplot(2, 3, 3)
        unique_labels, counts = np.unique(labels, return_counts=True)
        bars = ax3.bar(unique_labels, counts, color=colors[:len(unique_labels)])
        ax3.set_title('Cluster Sizes', fontsize=12, fontweight='bold')
        ax3.set_xlabel('Cluster', fontsize=10)
        ax3.set_ylabel('Number of Contributors', fontsize=10)
        
        for i, (bar, count) in enumerate(zip(bars, counts)):
            pct = 100 * count / len(labels)
            ax3.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 10,
                    f'{count}\n({pct:.1f}%)', ha='center', va='bottom', fontsize=8)
        
        # 4. Series length distribution
        ax4 = plt.subplot(2, 3, 4)
        length_by_cluster = []
        for cluster_id in range(k):
            cluster_mask = labels == cluster_id
            cluster_lengths = self.lengths[cluster_mask]
            length_by_cluster.append(cluster_lengths)
        
        bp = ax4.boxplot(length_by_cluster, labels=[f'C{i}' for i in range(k)],
                         patch_artist=True)
        for patch, color in zip(bp['boxes'], colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        
        ax4.set_title('Series Length by Cluster', fontsize=12, fontweight='bold')
        ax4.set_xlabel('Cluster', fontsize=10)
        ax4.set_ylabel('Series Length (weeks)', fontsize=10)
        ax4.grid(True, alpha=0.3, axis='y')
        
        # 5. Project type composition
        ax5 = plt.subplot(2, 3, 5)
        if 'project_type' in metadata.columns:
            composition = pd.crosstab(labels, metadata['project_type'], normalize='index') * 100
            composition.plot(kind='bar', stacked=True, ax=ax5, color=['#ff9999', '#66b3ff'])
            ax5.set_title('Cluster by Project Type', fontsize=12, fontweight='bold')
            ax5.set_xlabel('Cluster', fontsize=10)
            ax5.set_ylabel('Percentage', fontsize=10)
            ax5.legend(title='Project Type', fontsize=8)
            ax5.set_xticklabels(ax5.get_xticklabels(), rotation=0)
        
        # 6. Summary statistics
        ax6 = plt.subplot(2, 3, 6)
        summary_text = f"""DTW Clustering (k={k})
{'='*25}

Contributors: {len(labels):,}
Silhouette: {result['silhouette']:.4f}
Time: {result['elapsed_time']:.1f}s

Cluster Sizes:"""
        
        for i, count in enumerate(counts):
            pct = 100 * count / len(labels)
            summary_text += f"\n  C{i}: {count:,} ({pct:.1f}%)"
        
        ax6.text(0.1, 0.9, summary_text, transform=ax6.transAxes, fontsize=9,
                verticalalignment='top', fontfamily='monospace',
                bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.5))
        ax6.set_xlim(0, 1)
        ax6.set_ylim(0, 1)
        ax6.axis('off')
        ax6.set_title('Summary', fontsize=12, fontweight='bold')
        
        plt.suptitle(f'Memory-Optimized DTW Clustering (k={k})', fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        # Save with lower DPI to save memory
        filename = self.output_dir / f'dtw_k{k}_analysis.png'
        plt.savefig(filename, dpi=100, bbox_inches='tight')
        plt.close()
        
        # Force cleanup
        self.force_cleanup()
        
        self.log(f"Visualization saved: {filename}", "SAVE")
    
    def save_results_optimized(self, result, metadata):
        """
        Memory-optimized result saving.
        """
        k = result['k']
        
        # Save results as JSON
        json_results = {
            'k': k,
            'silhouette': float(result['silhouette']),
            'cluster_sizes': [int(c) for c in result['cluster_sizes']],
            'n_contributors': len(result['labels']),
            'elapsed_time': result['elapsed_time'],
            'length_stats': {
                'min': int(self.lengths.min()),
                'max': int(self.lengths.max()),
                'median': float(np.median(self.lengths)),
                'mean': float(self.lengths.mean())
            }
        }
        
        json_file = self.output_dir / f'dtw_k{k}_results.json'
        with open(json_file, 'w') as f:
            json.dump(json_results, f, indent=2)
        self.log(f"Results saved: {json_file}", "SAVE")
        
        # Save cluster assignments
        results_df = metadata.copy()
        results_df['cluster'] = result['labels']
        results_df['series_length'] = self.lengths
        
        csv_file = self.output_dir / f'dtw_k{k}_clusters.csv'
        results_df.to_csv(csv_file, index=False)
        self.log(f"Cluster assignments saved: {csv_file}", "SAVE")
        
        # Save only essential model data (skip large tslearn_dataset)
        pickle_file = self.output_dir / f'dtw_k{k}_results_only.pkl'
        with open(pickle_file, 'wb') as f:
            pickle.dump({
                'result': result,
                'metadata': metadata,
                'lengths': self.lengths
            }, f)
        self.log(f"Essential results saved: {pickle_file}", "SAVE")
    
    def run_optimized_analysis(self, k_values=[2, 3, 4], min_active_weeks=6):
        """
        Run memory-optimized DTW clustering analysis.
        """
        self.log("="*70, "INFO")
        self.log("MEMORY-OPTIMIZED DTW CLUSTERING", "START")
        self.log("="*70, "INFO")
        self.log(f"Testing k values: {k_values}", "INFO")
        self.log(f"Minimum activity: {min_active_weeks} weeks", "INFO")
        self.log("Using variable-length time series (no interpolation)", "INFO")
        self.log("", "MEMORY")
        
        # Load and filter data
        series_list, metadata = self.load_and_filter_optimized(min_active_weeks=min_active_weeks)
        
        # Prepare for DTW
        tslearn_dataset = self.prepare_for_dtw_optimized(series_list, scaling='minmax')
        
        # Clear original series list to save memory
        del series_list
        self.force_cleanup()
        
        # Run DTW clustering for each k
        all_results = []
        
        for i, k in enumerate(k_values):
            self.log(f"\n--- Processing k={k} ({i+1}/{len(k_values)}) ---", "INFO")
            
            # Perform DTW clustering
            result = self.cluster_with_dtw_optimized(tslearn_dataset, k)
            all_results.append(result)
            
            # Visualize results
            self.visualize_dtw_results_optimized(tslearn_dataset, result, metadata)
            
            # Save results
            self.save_results_optimized(result, metadata)
            
            # Force cleanup between k values
            self.force_cleanup()
            self.log("", "MEMORY")
        
        # Find best k
        best_result = max(all_results, key=lambda x: x['silhouette'])
        
        # Final cleanup
        del tslearn_dataset
        self.force_cleanup()
        
        self.log("\n" + "="*70, "INFO")
        self.log("ANALYSIS COMPLETE!", "SUCCESS")
        self.log("="*70, "INFO")
        
        # Summary
        self.log("\n📊 SUMMARY:", "INFO")
        for result in all_results:
            self.log(f"  k={result['k']}: silhouette={result['silhouette']:.4f}, "
                    f"time={result['elapsed_time']:.1f}s", "INFO")
        
        self.log(f"\n🏆 Best k={best_result['k']} with silhouette={best_result['silhouette']:.4f}", "SUCCESS")
        self.log(f"\nResults saved to: {self.output_dir}/", "INFO")
        self.log("", "MEMORY")
        
        return all_results


def main():
    """Main function for memory-optimized DTW clustering."""
    
    # Configuration
    data_path = "../step1/results/rolling_4week/weekly_pivot_for_dtw.csv"
    output_dir = "dtw_clustering_memory_optimized/"
    
    # Initialize memory-optimized DTW clustering
    dtw_clustering = MemoryOptimizedDTWClustering(
        data_path=data_path,
        output_dir=output_dir,
        verbose=True
    )
    
    # Run analysis for k=2, 3, 4 with memory optimization
    results = dtw_clustering.run_optimized_analysis(
        k_values=[2, 3, 4],
        min_active_weeks=6
    )
    
    print("\n" + "="*70)
    print("✅ MEMORY-OPTIMIZED DTW CLUSTERING COMPLETE!")
    print("="*70)
    print("\nOptimizations applied:")
    print("  • Memory monitoring and cleanup")
    print("  • Reduced DTW parameters (5 iter, 1 init)")
    print("  • Float32 precision to save memory")
    print("  • Smaller silhouette samples")
    print("  • Chunk-based data loading")
    print("  • Aggressive garbage collection")
    
    print(f"\nCheck results in: {output_dir}")


if __name__ == "__main__":
    main()